
# add upload_page to __init__.py:
# from .upload import upload_page