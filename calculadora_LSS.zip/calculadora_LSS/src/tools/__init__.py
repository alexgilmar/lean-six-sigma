# add dpmo_calculator_page to __init__.py:
from .dpmo_calculator import dpmo_calculator_page
